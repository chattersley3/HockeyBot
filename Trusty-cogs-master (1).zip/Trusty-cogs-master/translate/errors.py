class GoogleTranslateAPIError(Exception):
    """Raised when google translate has an oopsie"""
    pass
