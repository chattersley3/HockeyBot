from .hockey import Hockey


def setup(bot):
    bot.add_cog(Hockey(bot))
