from .covfefe import Covfefe


def setup(bot):
    bot.add_cog(Covfefe(bot))
