from .rekt import Rekt


def setup(bot):
    bot.add_cog(Rekt(bot))
