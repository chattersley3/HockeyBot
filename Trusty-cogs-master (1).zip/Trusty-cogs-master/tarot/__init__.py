from .tarotreading import TarotReading


def setup(bot):
    bot.add_cog(TarotReading(bot))
