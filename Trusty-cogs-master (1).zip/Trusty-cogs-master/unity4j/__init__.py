from .unity4j import Unity4J


def setup(bot):
    bot.add_cog(Unity4J(bot))
