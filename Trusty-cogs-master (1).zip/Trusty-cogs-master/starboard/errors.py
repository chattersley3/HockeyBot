class StarboardError(Exception):
    pass


class NoStarboardError(StarboardError):
    pass
