from .halo import Halo


def setup(bot):
    bot.add_cog(Halo(bot))
