from .faces import Faces


def setup(bot):
    bot.add_cog(Faces(bot))
