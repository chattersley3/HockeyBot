# TODO list for Trusty-cogs
*These are planned updates I would like to complete for each cog*

## Hockey
> Image only based on channel permissions

> Game day threads from associated subreddit

## Anime
> Rewrite for new API

## Activity
>Check for users last post on refresh and startup (allows for quicker kicking of inactive users)

## Badges
> Allow creation of templates through discord

## Starboard
> Allow multiple starboards per server

## Chatter
> Optimize for v3 and utilize async to get responses
