class TwitchError(Exception):
    pass
