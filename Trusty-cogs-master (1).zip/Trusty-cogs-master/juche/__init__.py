from .juche import Juche


def setup(bot):
    bot.add_cog(Juche(bot))
