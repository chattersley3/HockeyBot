from .imgflip import Imgflip


def setup(bot):
    bot.add_cog(Imgflip(bot))
