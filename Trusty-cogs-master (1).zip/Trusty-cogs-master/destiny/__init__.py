from .destiny import Destiny


def setup(bot):
    bot.add_cog(Destiny(bot))
